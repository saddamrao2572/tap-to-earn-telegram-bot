<footer>
    <p>&copy; 2025 Crypto Tap2Earn Game. All rights reserved.</p>
</footer>

<div class="menu-bar">
    <a href="dashboard.php">Dashboard</a>
    <a href="daily_task.php">Daily Tasks</a>
    <a href="video_view.php">Watch Videos</a>
    <a href="boosters.php">Boosters</a>
    <a href="logout.php">Logout</a>
</div>
</body>
</html>
