<?php include('../includes/header.php'); ?>
<div class="container">
    <h2>Login</h2>
    <p>Login with your Telegram account:</p>
    <script async src="https://telegram.org/js/telegram-widget.js?7"
            data-telegram-login="wolfworldgame_bot"
            data-size="large"
            data-radius="10"
            data-request-access="write"></script>
</div>
<?php include('../includes/footer.php'); ?>


