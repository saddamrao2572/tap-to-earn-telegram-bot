<?php 
session_start();
include '../includes/header.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_POST['update_wallet']) {
    $new_wallet = $_POST['wallet_address'];

    // Update wallet address
    $stmt = $db->prepare("UPDATE users SET wallet_address = ? WHERE telegram_id = ?");
    $stmt->bind_param("ss", $new_wallet, $user_id);
    $stmt->execute();

    echo "Wallet address updated successfully!";
}

?>

<form method="POST">
    <label for="wallet_address">New Wallet Address:</label>
    <input type="text" name="wallet_address" required>
    <button name="update_wallet">Update Wallet Address</button>
</form>

<?php include '../includes/footer.php'; ?>
