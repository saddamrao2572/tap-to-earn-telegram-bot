<?php 
session_start();
include '../includes/header.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Add video viewing logic and reward
if ($_POST['watched']) {
    // Reward user for watching the video
    $stmt = $db->prepare("UPDATE users SET balance = balance + 50 WHERE telegram_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();

    echo "You have earned 50 coins for watching the video!";
}

?>

<form method="POST">
    <button name="watched">Watch Video</button>
</form>

<?php include '../includes/footer.php'; ?>
