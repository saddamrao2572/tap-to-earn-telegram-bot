<?php 
session_start();
include '../includes/header.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if the user has completed the task today
$stmt = $db->prepare("SELECT * FROM daily_tasks WHERE user_id = ? AND date = CURDATE()");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$task = $result->fetch_assoc();

if ($task) {
    echo "You have already completed today's task.";
} else {
    // Reward user
    $stmt = $db->prepare("INSERT INTO daily_tasks (user_id, date) VALUES (?, CURDATE())");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $stmt = $db->prepare("UPDATE users SET balance = balance + 100 WHERE telegram_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();

    echo "Congratulations! You completed your daily task and earned 100 coins!";
}

?>

<?php include '../includes/footer.php'; ?>
