<?php 
session_start();
include '../includes/header.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
// Get user details from the database
$stmt = $db->prepare("SELECT * FROM users WHERE telegram_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<h2>Welcome, <?php echo $user['username']; ?></h2>

<!-- Dashboard Content -->
<p>Your current balance: <?php echo $user['balance']; ?> coins</p>
<a href="daily_task.php">Complete Daily Tasks</a> | 
<a href="boosters.php">Buy Boosters</a> | 
<a href="video_view.php">Watch Videos</a>

<?php include '../includes/footer.php'; ?>
