<?php 
session_start();
include '../includes/header.php'; 

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_POST['buy_boost']) {
    // Deduct coins and activate booster
    $stmt = $db->prepare("UPDATE users SET balance = balance - 50 WHERE telegram_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();

    echo "You have successfully bought a booster!";
}

?>

<form method="POST">
    <button name="buy_boost">Buy Speed Booster (50 coins)</button>
</form>

<?php include '../includes/footer.php'; ?>
