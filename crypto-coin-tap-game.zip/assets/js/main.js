// Function for tap to earn coins
document.getElementById("tapButton").addEventListener("click", function () {
    let userId = 1;  // Assume user is logged in, you can replace this dynamically.
    fetch('/api/tapEarn.php', {
        method: 'POST',
        body: JSON.stringify({ userId: userId }),
        headers: {
            'Content-Type': 'application/json'
        }
    }).then(response => response.json())
      .then(data => {
        if (data.success) {
            alert("You've earned " + data.coinsEarned + " coins!");
            location.reload();
        } else {
            alert("Error: " + data.message);
        }
    });
});
