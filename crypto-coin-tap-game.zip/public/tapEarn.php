<?php
include('../config/database.php');
include('../src/User.php');

$data = json_decode(file_get_contents("php://input"));

$userId = $data->userId;
$coinsEarned = rand(10, 50);  // Random coins earned on each tap

$user = new User($conn);
$user->updateCoins($userId, $coinsEarned);

$response = [
    'success' => true,
    'coinsEarned' => $coinsEarned
];

echo json_encode($response);
?>
