<?php
include('../config/database.php');
include('../src/User.php');

$userId = 1; // Example user ID, replace with actual user session
$user = new User($conn);
$userData = $user->getUserData($userId);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Screen</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<header>
    <h1>Welcome to the Game, <?php echo $userData['username']; ?>!</h1>
</header>

<div class="container">
    <div class="game-container">
        <p>Your current coins: <?php echo $userData['coins']; ?></p>
        <button id="tapButton" class="coin-button">Tap to Earn Coins</button>
    </div>
</div>

<script src="/assets/js/main.js"></script>
</body>
</html>
