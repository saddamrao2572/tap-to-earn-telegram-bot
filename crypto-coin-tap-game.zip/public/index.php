<?php
include('../config/database.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crypto Coin Tap2Earn</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<header>
    <h1>Crypto Coin Tap2Earn Game</h1>
</header>

<div class="container">
    <div class="game-container">
        <h2>Tap to earn coins!</h2>
        <button id="tapButton" class="coin-button">Tap Here</button>
    </div>
</div>

<script src="/assets/js/main.js"></script>
</body>
</html>
