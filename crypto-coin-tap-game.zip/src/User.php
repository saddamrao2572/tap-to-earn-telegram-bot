<?php
class User
{
    private $conn;
    
    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function getUserData($userId)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = :userId");
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateCoins($userId, $coins)
    {
        $stmt = $this->conn->prepare("UPDATE users SET coins = coins + :coins WHERE id = :userId");
        $stmt->bindParam(':coins', $coins);
        $stmt->bindParam(':userId', $userId);
        $stmt->execute();
    }
}
?>
