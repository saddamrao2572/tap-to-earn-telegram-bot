<?php
session_start();
require_once '../config/db_config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $wallet_address = $_POST['wallet_address'];

    // Validate Tron wallet address format (basic validation)
    if (!preg_match("/^T[a-zA-Z0-9]{33}$/", $wallet_address)) {
        echo "Invalid Tron wallet address!";
        exit;
    }

    // Update wallet address in the database
    $stmt = $db->prepare("UPDATE users SET tron_wallet_address = ? WHERE user_id = ?");
    $stmt->bind_param("si", $wallet_address, $user_id);
    $stmt->execute();

    echo "Wallet address updated successfully!";
}
?>
