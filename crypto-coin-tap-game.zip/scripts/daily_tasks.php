<?php
include('config/db_config.php');

$query = "SELECT * FROM daily_tasks WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo "<p>" . $row['task_name'] . " - Status: " . $row['status'] . "</p>";
}

if (isset($_POST['complete_task'])) {
    $task_id = $_POST['task_id'];
    $query = "UPDATE daily_tasks SET status = 'completed', completed_at = NOW() WHERE task_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $task_id);
    $stmt->execute();
}
?>
