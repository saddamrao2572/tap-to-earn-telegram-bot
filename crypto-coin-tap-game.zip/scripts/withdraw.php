<?php
session_start();
require_once 'tron_wallet.php';
require_once '../config/db_config.php'; // Ensure the database connection is established

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$withdraw_amount = $_POST['amount'];
$withdraw_address = $_POST['address']; // The user's Tron wallet address
$private_key = $_POST['private_key']; // The user's private key (for signing the transaction)

// Function to check if the user has enough balance in the system
function check_user_balance($user_id) {
    global $db;
    $stmt = $db->prepare("SELECT coin_amount FROM coins WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();
    
    return $data['coin_amount'];
}

// Handle the withdrawal
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the user has enough balance
    $user_balance = check_user_balance($user_id);
    
    if ($withdraw_amount > $user_balance) {
        echo "Insufficient balance!";
        exit;
    }
    
    // Send the withdrawal transaction
    try {
        // Send TRX using the Tron wallet function (you need a secure method for signing transactions)
        $status = send_trx($user_balance, $private_key, $withdraw_address, $withdraw_amount);
        
        if ($status) {
            // Deduct the withdrawn amount from the user's coins in the database
            $stmt = $db->prepare("UPDATE coins SET coin_amount = coin_amount - ? WHERE user_id = ?");
            $stmt->bind_param("ii", $withdraw_amount, $user_id);
            $stmt->execute();
            
            echo "Withdrawal Successful!";
        } else {
            echo "Error processing the withdrawal.";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!-- Withdrawal Form -->
<form action="withdraw.php" method="POST">
    <label for="amount">Enter Amount to Withdraw (TRX):</label>
    <input type="number" name="amount" required>
    
    <label for="address">Enter Your Tron Wallet Address:</label>
    <input type="text" name="address" required>
    
    <label for="private_key">Enter Your Private Key:</label>
    <input type="text" name="private_key" required>
    
    <button type="submit">Withdraw</button>
</form>
