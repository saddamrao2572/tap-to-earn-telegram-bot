<?php
include('config/db_config.php');

if (isset($_POST['purchase_booster'])) {
    $user_id = $_SESSION['user_id'];
    $booster_name = $_POST['booster_name'];
    $duration = $_POST['duration'];

    $query = "INSERT INTO boosters (user_id, booster_name, duration) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isi", $user_id, $booster_name, $duration);
    $stmt->execute();

    echo "Booster activated!";
}
?>
