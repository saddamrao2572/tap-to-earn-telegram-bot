<?php
// telegram_auth.php
require_once '../config/db_config.php';

$bot_token = '7524704889:AAG0FbEXaxaqnPP1ZErjEDnQDJjKqV9UX9w';
$bot_api_url = "https://api.telegram.org/bot$bot_token/";

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Call Telegram API to get user info
    $response = file_get_contents($bot_api_url . "getMe?code=$code");
    $user_info = json_decode($response, true);

    if ($user_info['ok']) {
        // If user exists in database, log them in
        $telegram_id = $user_info['result']['id'];
        $username = $user_info['result']['username'];

        // Check if user is already registered
        $stmt = $db->prepare("SELECT * FROM users WHERE telegram_id = ?");
        $stmt->bind_param("s", $telegram_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Existing user, log in
            session_start();
            $_SESSION['user_id'] = $telegram_id;
            header("Location: ../views/dashboard.php");
        } else {
            // New user, register them
            $stmt = $db->prepare("INSERT INTO users (telegram_id, username) VALUES (?, ?)");
            $stmt->bind_param("ss", $telegram_id, $username);
            $stmt->execute();

            session_start();
            $_SESSION['user_id'] = $telegram_id;
            header("Location: ../views/dashboard.php");
        }
    } else {
        echo "Telegram authentication failed.";
    }
}
?>
